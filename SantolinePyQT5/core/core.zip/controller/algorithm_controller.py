import os

from qgis._core import *

from ..model import algorithm_model, canvas_model
from ..libs import file_connector
from . import controller, canvas_controller
from ..model import canvas_model

import json
import threading

class AlgorithmController(controller.AController):
    def __init__(self, view, canvasModel):
        super().__init__(view)
        self.algorithmModel_ = algorithm_model.AlgorithmModel(self)
        self.algorithmModel_.addObserver(view)
        self.canvasModel_=canvasModel
        
    def algorithm(self, algorithm):
        self.algorithmModel_.algorithm(algorithm)
        
    def duree(self, duree):
        self.algorithmModel_.duree(duree)
        
    def waterReserve(self, waterReserve):
        self.algorithmModel_.waterReserve(waterReserve)
        
    def temperature(self, temperature):
        self.algorithmModel_.temperature(temperature)

    def process(self, process):
        self.algorithmModel_.process(process)
        
    def accept(self):
        print("accept! \n")
        with open('parametreAlgo.json', 'w') as outfile:
            json.dump({"algorithm": "Maillage Variable",
                        "waterReserve": 6,
                        "duree": "00:00:05",
                        "temperature": 35,
                        "nbProcess": 2,
                        "dimension": 25,
                        "nbDivisionCellule": 25,
                        "contourInitial":self.canvasModel_.jsonify(),
                       "listeObstacle": self.canvasModel_.obstacleJsonify()}, outfile)
        self.close()
        # lancer le programme algo avec les parametre algo et la carte de vent et la sortie est le resultat  de simulation
        var = os.popen(
            "..\\algo\\cmake-build-debug\\algo.exe parametreAlgo.json maps\\truc.json resultatSimulation.json")
        data = var.readlines()


        # recuperer le resultat de simulation
        resultatSimulation = []
        with open(b"resultatSimulation.json", 'r', encoding='utf-8') as f:
            resultatSimulation = json.load(f)
        # print(resultatSimulation)

        # renvoyer le resultat au santoline_view
        for p in resultatSimulation:
            qp = QgsPointXY(p[0], p[1])
            self.canvasModel_.propagation_.append(qp)

        print(self.canvasModel_.propagation_)
        
    def close(self):
        self.view_.hide()