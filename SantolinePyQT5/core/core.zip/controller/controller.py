class AController:
    def __init__(self, view):
        self.view_ = view