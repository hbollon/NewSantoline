from random import randrange

from qgis.gui import *#QgsMapCanvas
from qgis.core import *#QgsRasterLayer, QgsApplication
from qgis.PyQt.QtWidgets import *#QMainWindow, QWidget, QTabWidget, QPushButton
from qgis.PyQt.QtCore import *#QSize
from qgis.PyQt.QtGui import *#QFrame
import math

from . import wind_view, algorithm_view, departements_choices_view, legend_view
from ..controller import *
from ..libs import *

import threading
import json
import os

class Santoline(QMainWindow, observable.Observer):
    def __init__(self):
        super().__init__()
        self.keys = []
        self.firstToolbar_ = None
        self.secondToolbar_ = None 
        self.left_toolbar_ = None
        self.simulation = None
        self.simuler = None
        self.actionEmitPoint = None 
        self.actionCancelContour = None
        self.actions = None 
        self.actionLargageCEau = None 
        self.actionLargageHEau = None
        self.actionLargageCRetardant = None
        self.actionLargageHRetardant = None
        self.actionAttaqueJalonnement = None
        self.actionLigneAppui = None
        self.actionObstacle = None
        self.vents = None
        self.roseVents = None
        self.calculVents = None
        self.afficheVents = None
        self.afficheVentsPentes = None
        self.statusbar_ = None
        self.progressbar_ = None
        self.canvas_ = None
        self.wind_window_ = None
        self.parameter_window_ = None
        self.departements_choices_window_ = None
        self.thread_ = None
        self.fireLayer_ = None
        self.rubber_contour_feu_ = None
        self.propagations_rubber_ = []
        self.controller_ = canvas_controller.CanvasController(self)
        self.addTrackTool = None
        self.eau_HBE_maker = None
        self.retardant_HBE_maker = None
        self.eau_ABE_marker = None
        self.eau_ABE_marker2 = None
        self.retartant_ABE_marker = None
        self.retartant_ABE_marker2 = None
        self.obstacle_marker = None
        self.windLayer_ = None
        self.slopeLayer_ = None
        self.layers = []
        self.features = []
        self.windmapdisplayed = False

        self.initUI()

    def initUI(self):
        self.setWindowTitle("Santoline")
        self.setGeometry(90, 90, 1280, 960)

        # Ribbon bar / Barre ruban
        self.firstToolbar_ = self.addToolBar("First tool bar")
        self.firstToolbar_.setMovable(False)
        self.firstToolbar_.setFloatable(False)

        self.addToolBarBreak()
        self.secondToolbar_ = self.addToolBar("Second tool bar")
        self.secondToolbar_.setMovable(False)
        self.secondToolbar_.setFloatable(False)
        
        self.addToolBarBreak()
        self.left_toolbar_ = self.addToolBar("Left tool bar")


        self.left_toolbar_.setMovable(False)
        self.left_toolbar_.setFloatable(False)
        self.addToolBar(QtCore.Qt.LeftToolBarArea,self.left_toolbar_)  # On positionne la toolbar à gauche

        self.statusbar_ = QStatusBar(self)
        self.setStatusBar(self.statusbar_)
        self.progressbar_ = QProgressBar(self.statusbar_)
        self.statusbar_.addWidget(self.progressbar_)
        

        self.parameter_window_ = algorithm_view.ParameterWindow(self.controller_.canvasModel_)
        self.departements_choices_window_ = departements_choices_view.Departements_Choices_Window()

        
        # Ribbon bar Departement / Barre ruban Département
        departement = QToolButton(self.secondToolbar_)
        departement.setCheckable(False)
        departement.setAutoExclusive(True)
        departement.setText("Departements")
        self.secondToolbar_.addWidget(departement)
        departement.clicked.connect(self.controller_.departements_choices)

        # Interface body / Corps de l'interface
        self.canvas_ = QgsMapCanvas(self)
        self.canvas_.setCachingEnabled(True)
        self.canvas_.setParallelRenderingEnabled(True)
        self.setCentralWidget(self.canvas_)

        self.wind_window_ = wind_view.WindWindow(self)

        # Map tools
        toolPan = QgsMapToolPan(self.canvas_)
        toolZoomIn = QgsMapToolZoom(self.canvas_, False)
        toolZoomOut = QgsMapToolZoom(self.canvas_, True)
        toolEdit = QgsMapToolEmitPoint(self.canvas_)
        
        actionPan = QAction(QIcon("icons\\hand.png"), "Pan", self)
        actionPan.setCheckable(True)
        toolPan.setAction(actionPan)
        actionPan.triggered.connect(lambda : self.canvas_.setMapTool(toolPan))
        
        actionZoomIn = QAction(QIcon("icons\\zoom_in.png"), "ZoomIn", self)
        actionZoomIn.setCheckable(True)
        toolZoomIn.setAction(actionZoomIn)
        actionZoomIn.triggered.connect(lambda : self.canvas_.setMapTool(toolZoomIn))
        
        actionZoomOut = QAction(QIcon("icons\\zoom_out.png"), "ZoomOut", self)
        actionZoomOut.setCheckable(True)
        toolZoomOut.setAction(actionZoomOut)
        actionZoomOut.triggered.connect(lambda : self.canvas_.setMapTool(toolZoomOut))

        # Simulation
        self.simulation = QToolButton(self.secondToolbar_)
        self.simulation.setText("Simulation")
        self.simulation.setCheckable(True)
        self.simulation.setAutoExclusive(True)
        #widget ajouté plus bas, après les actions et les vents
        self.simulation.clicked.connect(self.affichageToolsSimulation)
        
        self.simuler = QAction(QIcon("icons\\validation.png"), "Simuler", self)
        self.simuler.setCheckable(False)
        toolEdit.setAction(self.simuler)
        self.simuler.triggered.connect(self.controller_.algorithm)
        self.simuler.setVisible(False)

        toolContour = QgsMapToolEmitPoint(self.canvas_)
        toolContour.canvasClicked.connect(self.controller_.addPointContour)
        self.actionEmitPoint = QAction(QIcon("icons\\map_edit.png"), "Dessiner Contours", self)
        self.actionEmitPoint.setCheckable(True)
        self.actionEmitPoint.triggered.connect(lambda: self.canvas_.setMapTool(toolContour))
        self.actionEmitPoint.setVisible(False)

        self.actionCancelContour = QAction(QIcon("icons\\cancel.png"), "Détruire Contours", self)
        self.actionCancelContour.setCheckable(False)
        self.actionCancelContour.triggered.connect(self.controller_.clearPointContour)
        self.actionCancelContour.setVisible(False)

        self.firstToolbar_.addAction(actionPan)
        self.firstToolbar_.addAction(actionZoomIn)
        self.firstToolbar_.addAction(actionZoomOut)
        self.left_toolbar_.addAction(self.simuler)
        self.left_toolbar_.addAction(self.actionEmitPoint)
        self.left_toolbar_.addAction(self.actionCancelContour)
        # Actions pompiers
        self.actions = QToolButton(self.secondToolbar_)
        self.actions.setText("Actions")
        self.actions.setCheckable(True)
        self.actions.setChecked(True)
        self.actions.setAutoExclusive(True)
        self.secondToolbar_.addWidget(self.actions)
        self.actions.clicked.connect(self.affichageToolsActions)

        toolLargageCEau = QgsMapToolEmitPoint(self.canvas_)
        toolLargageCEau.canvasClicked.connect(self.controller_.addPointLargageEauABE)
        self.actionLargageCEau = QAction(QIcon("icons\\actions\\ceau.png"), "Largage eau ABE", self)
        self.actionLargageCEau.setCheckable(True)
        self.actionLargageCEau.triggered.connect(lambda: self.canvas_.setMapTool(toolLargageCEau))
        self.left_toolbar_.addAction(self.actionLargageCEau)

        toolLargageHEau = QgsMapToolEmitPoint(self.canvas_)
        toolLargageHEau.canvasClicked.connect(self.controller_.addPointLargageEauHBE)
        self.actionLargageHEau = QAction(QIcon("icons\\actions\\heau.png"), "Largage eau HBE", self)
        self.actionLargageHEau.setCheckable(True)
        self.actionLargageHEau.triggered.connect(lambda: self.canvas_.setMapTool(toolLargageHEau))
        self.left_toolbar_.addAction(self.actionLargageHEau)

        toolLargageCRetardant = QgsMapToolEmitPoint(self.canvas_)
        toolLargageCRetardant.canvasClicked.connect(self.controller_.addPointLargageCRetartant)
        self.actionLargageCRetardant = QAction(QIcon("icons\\actions\\cretardant.png"), "Largage retardant ABE", self)
        self.actionLargageCRetardant.setCheckable(True)
        self.actionLargageCRetardant.triggered.connect(lambda: self.canvas_.setMapTool(toolLargageCRetardant))
        self.left_toolbar_.addAction(self.actionLargageCRetardant)

        toolLargageHRetardant = QgsMapToolEmitPoint(self.canvas_)
        toolLargageHRetardant.canvasClicked.connect(self.controller_.addPointLargageHRetardant)
        self.actionLargageHRetardant = QAction(QIcon("icons\\actions\\hretardant.png"), "Largage retardant HBE", self)
        self.actionLargageHRetardant.setCheckable(True)
        self.actionLargageHRetardant.triggered.connect(lambda: self.canvas_.setMapTool(toolLargageHRetardant))
        self.left_toolbar_.addAction(self.actionLargageHRetardant)



        toolAttaqueJalonnement = QgsMapToolEmitPoint(self.canvas_)
        toolAttaqueJalonnement.canvasClicked.connect(self.controller_.addPointJalonnement)
        self.actionAttaqueJalonnement = QAction(QIcon("icons\\actions\\jalonnementS.png"), "Attaque de jalonnement", self)
        self.actionAttaqueJalonnement.setCheckable(True)
        self.actionAttaqueJalonnement.triggered.connect(lambda: self.canvas_.setMapTool( toolAttaqueJalonnement))
        self.left_toolbar_.addAction(self.actionAttaqueJalonnement)

        toolLigneAppui = QgsMapToolEmitPoint(self.canvas_)
        toolLigneAppui.canvasClicked.connect(self.controller_.addPointAppui)
        self.actionLigneAppui = QAction(QIcon("icons\\actions\\ligneappui.png"), "Ligne d'appui", self)
        self.actionLigneAppui.setCheckable(True)
        self.left_toolbar_.addAction(self.actionLigneAppui)
        self.actionLigneAppui.triggered.connect(lambda: self.canvas_.setMapTool(toolLigneAppui))

        toolObstacle = QgsMapToolEmitPoint(self.canvas_)
        toolObstacle.canvasClicked.connect(self.controller_.addPointObstacle)
        self.actionObstacle = QAction(QIcon("icons\\actions\\obstacle.png"), "Obstacle naturel", self)
        self.actionObstacle.setCheckable(True)
        self.left_toolbar_.addAction(self.actionObstacle)
        self.actionObstacle.triggered.connect(lambda: self.canvas_.setMapTool(toolObstacle))



        alignmentGroup = QActionGroup(self); # for auto-exclusive actions
        alignmentGroup.addAction(self.actionLargageCEau)
        alignmentGroup.addAction(self.actionLargageHEau)
        alignmentGroup.addAction(self.actionLargageCRetardant)
        alignmentGroup.addAction(self.actionLargageHRetardant)
        alignmentGroup.addAction(self.actionAttaqueJalonnement)
        alignmentGroup.addAction(self.actionLigneAppui)
        alignmentGroup.addAction(self.actionObstacle)
        
        toolEdit.canvasClicked.connect(self.controller_.addPointContour)

        # Vents
        self.vents = QToolButton(self.secondToolbar_)
        self.vents.setText("Vents")
        self.vents.setCheckable(True)
        self.vents.setAutoExclusive(True)
        self.vents.clicked.connect(self.affichageToolsVents)
        self.secondToolbar_.addWidget(self.vents)
        
        self.secondToolbar_.addWidget(self.simulation)

        toolRoseVents = QgsMapToolEmitPoint(self.canvas_)
        toolRoseVents.canvasClicked.connect(self.controller_.setRoseVents)
        self.roseVents = QAction(QIcon("icons\\roseVents.png"), "Point de reference pour le calcul des vents", self)
        self.roseVents.setCheckable(False)
        self.roseVents.setVisible(False)
        self.roseVents.triggered.connect(lambda: self.canvas_.setMapTool(toolRoseVents))

        self.calculVents = QAction(QIcon("icons\\MancheAir.png"), "Calculer la carte des vents", self)
        self.calculVents.setCheckable(False)
        self.calculVents.setVisible(False)
        self.calculVents.triggered.connect(self.controller_.wind)
        
        self.afficheVents = QAction(QIcon("icons\\VentLogo2.png"), "Afficher la carte des vents", self)
        self.afficheVents.setCheckable(True)
        self.afficheVents.setVisible(False)
        self.afficheVents.triggered.connect(self.afficheCanvasVents)

        
        self.afficheVentsPentes = QAction(QIcon("icons\\VentPenteLogo2.png"), "Afficher la carte vents-pentes", self)
        self.afficheVentsPentes.setCheckable(True)
        self.afficheVentsPentes.setVisible(False)
        self.afficheVentsPentes.triggered.connect(self.afficheCanvasSlope)

        alignmentGroup2 = QActionGroup(self);
        alignmentGroup2.addAction(self.afficheVents)
        alignmentGroup2.addAction(self.afficheVentsPentes)
        
        self.left_toolbar_.addAction(self.calculVents)
        self.left_toolbar_.addAction(self.roseVents)
        self.left_toolbar_.addAction(self.afficheVents)
        self.left_toolbar_.addAction(self.afficheVentsPentes)
        
        self.reglages = QToolButton(self.secondToolbar_)
        self.reglages.setText("Réglages")
        self.reglages.setCheckable(False)
        self.reglages.setAutoExclusive(True)
        #self.reglages.clicked.connect()
        
        self.secondToolbar_.addWidget(self.reglages)
        
        self.departements_choices_window_.controller_.view_.valider_.clicked.connect(
            lambda: self.controller_.map(self.departements_choices_window_.controller_.model_.departement_courant))



        self.slopeLayer_ = self.windLayerInit('maps\\carteVent.json', '150,150,0,200', 1,True)
        self.windLayer_ = self.windLayerInit('maps\\result2.json', '0,150,0,200', 1,True)

        self.show()


    ###---Procedures d'affichage des barres d'outils---###

    # def afficheCanvasVents(self):
    #     print(self.canvas_.scale())
    #     self.layers.reverse()
    #     self.canvas_.setLayers(self.layers)
    #     self.canvas_.refresh()
    #     if (self.canvas_.scale() < 1400000000):
    #         self.windmapdisplayed =True

    def cleanToolbar(self, toolbar) :
        for action in toolbar.actions():
            action.setVisible(False)

    def affichageToolsActions(self) :
        self.cleanToolbar(self.left_toolbar_)
        self.actionLargageCEau.setVisible(True)
        self.actionLargageHEau.setVisible(True)
        self.actionLargageCRetardant.setVisible(True)
        self.actionLargageHRetardant.setVisible(True)
        self.actionAttaqueJalonnement.setVisible(True)
        self.actionLigneAppui.setVisible(True)
        self.actionObstacle.setVisible(True)
    
    def affichageToolsVents(self):
        self.cleanToolbar(self.left_toolbar_)
        self.roseVents.setVisible(True)
        self.calculVents.setVisible(True)
        self.afficheVents.setVisible(True)
        self.afficheVentsPentes.setVisible(True)
    
    def affichageToolsSimulation(self) : 
        self.cleanToolbar(self.left_toolbar_)
        self.actionEmitPoint.setVisible(True)
        self.actionCancelContour.setVisible(True)
        self.simuler.setVisible(True)

    ###---Procedures d'affichages des elements de la carte---###

    def afficheCanvasSlope(self):
        if self.slopeLayer_ in self.layers:
            self.layers.remove(self.slopeLayer_)
        else:
            self.layers.insert(0,self.slopeLayer_)

        if self.windLayer_ in self.layers :
            self.layers.remove(self.windLayer_)

        self.canvas_.setLayers(self.layers)

    def afficheCanvasVents(self):
        if self.windLayer_ in self.layers:
            self.layers.remove(self.windLayer_)
        else:
            self.layers.insert(0,self.windLayer_)

        if self.slopeLayer_ in self.layers :
            self.layers.remove(self.slopeLayer_)

        self.canvas_.setLayers(self.layers)

    def windLayerInit(self,path,color,densite, type):
        layer= QgsVectorLayer("Point?field=angle:double", "Wind Layer", "memory")
        provider = layer.dataProvider()
        fields = provider.fields()
        with open(path, 'r') as f:
            windMap = json.load(f)

        i = 0
        features = []
        for wind in windMap:
            if i % densite == 0:
                symbol = QgsMarkerSymbol.createSimple({'name': 'arrow', 'color':color,'outline_color': 'black', 'outline_width': '0'})

                symbol.setAngle(i)
                layer.renderer().setSymbol(symbol)

                feature = QgsFeature()
                feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(wind['x'], wind['y'])))
                feature.setFields(fields)
                if type:
                    x = wind['wind'][0]
                    y = wind['wind'][1]
                else:
                    x = wind['slope_vector'][0]+ wind['wind'][0]
                    y = wind['slope_vector'][1]+ wind['wind'][1]

                if x==0 and y==0:
                    alpha = 0

                elif x ==0:
                    alpha=90-((y/abs(y))*90)

                elif y==0:
                    alpha=(x/abs(x))*90
                elif y<0:
                    alpha = 180+math.degrees(math.atan(x/y))
                else:
                    alpha = math.degrees(math.atan(x/y))

                feature.setAttribute("angle", alpha)



                features.append(feature)

            i += 1

        provider.addFeatures(features)

        layer.updateExtents()
        fni = provider.fieldNameIndex('angle')
        unique_values = layer.dataProvider().uniqueValues(fni)
        categories = []

        for i in unique_values:
            symbol = QgsMarkerSymbol.createSimple({'name': 'arrow', 'color':color,'outline_color': 'black', 'outline_width': '0'})
            symbol.setAngle(180+i)
            symbol.setSize(3)
            category = QgsRendererCategory(i, symbol, str(i))
            # entry for the list of category items
            categories.append(category)

        renderer = QgsCategorizedSymbolRenderer('angle', categories)
        layer.setRenderer(renderer)
        return layer

    def update(self, model):
        if model.change():
            self.change(model.map_)
        self.update_contour(model)
        self.update_propagation(model)
        self.update_largage_eau_ABE(model)
        self.update_largage_eau_HBE(model)
        self.update_largage_retartant_HBE(model)
        self.update_largage_retartant_ABE(model)
        self.update_appui(model)
        self.update_jalonnement(model)
        self.update_obstacle(model)


    def update_contour(self, model):
        list_points = model.contour_feu_
        if len(list_points) > 1:
            if self.rubber_contour_feu_ == None:
                self.rubber_contour_feu_ = QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry)
            polygon = QgsGeometry.fromPolygonXY([list_points])
            self.rubber_contour_feu_.setToGeometry(polygon, None)
            self.rubber_contour_feu_.setColor(QColor(255, 0, 0, 255))
            self.rubber_contour_feu_.setFillColor(QColor(255, 128, 0, 128))
            self.rubber_contour_feu_.setWidth(3)
            
    def update_propagation(self, model):
        for pi in model.propagation_:
            p = QgsPointXY(pi.x(), pi.y())
            self.eau_ABE_marker = QgsVertexMarker(self.canvas_)
            self.eau_ABE_marker.setCenter(p)
            self.eau_ABE_marker.setFillColor(QColor(255, 0, 0))
            self.eau_ABE_marker.setIconSize(5)
            self.eau_ABE_marker.setIconType(QgsVertexMarker.ICON_CIRCLE)
        # if len(model.propagation_) > 0:
        #     for i in range(len(model.propagation_)):
        #         if len(self.propagations_rubber_) <= i:
        #             self.propagations_rubber_.append(QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry))
        #         points = QgsGeometry.fromMultiPointXY(model.propagation_[i])
        #         self.propagations_rubber_[i].setToGeometry(points, None)
        #         self.propagations_rubber_[i].setColor(QColor(255,0,0, 255))
        #         self.propagations_rubber_[i].setWidth(3)

    def update_largage_eau_ABE(self, model):
        list_points = model.largage_eau_ABE[len(model.largage_eau_ABE) - 1]
        if len(list_points) > 1:

            dernier_point2 = QgsPointXY(list_points[len(list_points) - 2].x(), list_points[len(list_points) - 2].y())
            dernier_point = QgsPointXY(list_points[len(list_points) - 1].x(), list_points[len(list_points) - 1].y())
            # print(dernier_point)
            print(dernier_point2)
            p1 = QgsPointXY(dernier_point2.x(), dernier_point2.y())
            p2 = QgsPointXY(dernier_point.x(), dernier_point.y())
            largeur = p2.x() - p1.x()
            hauteur = p2.y() - p1.y()

            dernierSegment = []
            dernierSegment.append(p1)
            dernierSegment.append(p2)

            rubber = QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry)
            polygon = QgsGeometry.fromPolylineXY(dernierSegment)

            longueur = math.sqrt(largeur ** 2 + hauteur ** 2)
            nb_point = int(longueur / 15)

            rubber.setToGeometry(polygon, None)
            rubber.setColor(QColor(0, 110, 255, 255))
            rubber.setWidth(3)
            rubber.setLineStyle(Qt.DotLine)


            self.eau_ABE_marker2 = QgsVertexMarker(self.canvas_)
            self.eau_ABE_marker2.setCenter(p1)
            self.eau_ABE_marker2.setColor(QColor(255, 255, 255))
            self.eau_ABE_marker2.setIconSize(4)
            self.eau_ABE_marker2.setIconType(QgsVertexMarker.ICON_BOX)
            self.eau_ABE_marker2.setPenWidth(4)
            self.eau_ABE_marker2.updatePosition()

            self.eau_ABE_marker = QgsVertexMarker(self.canvas_)
            self.eau_ABE_marker.setCenter(p1)
            self.eau_ABE_marker.setColor(QColor(0, 110, 255))
            self.eau_ABE_marker.setFillColor(QColor(0, 110, 255))
            self.eau_ABE_marker.setIconSize(8)
            self.eau_ABE_marker.setIconType(QgsVertexMarker.ICON_BOX)
            self.eau_ABE_marker.setPenWidth(2)
            self.eau_ABE_marker.updatePosition()


            for i in range(0, nb_point):
                dx = largeur / nb_point
                dy = hauteur / nb_point
                p = QgsPointXY(dernier_point.x() - dx * i, dernier_point.y() - dy * i)

                self.eau_ABE_marker2 = QgsVertexMarker(self.canvas_)
                self.eau_ABE_marker2.setCenter(p)
                self.eau_ABE_marker2.setColor(QColor(255, 255, 255))
                self.eau_ABE_marker2.setIconSize(4)
                self.eau_ABE_marker2.setIconType(QgsVertexMarker.ICON_BOX)
                self.eau_ABE_marker2.setPenWidth(4)
                self.eau_ABE_marker2.updatePosition()

                self.eau_ABE_marker = QgsVertexMarker(self.canvas_)
                self.eau_ABE_marker.setCenter(p)
                self.eau_ABE_marker.setColor(QColor(0, 110, 255))
                self.eau_ABE_marker.setFillColor(QColor(0, 110, 255))
                self.eau_ABE_marker.setIconSize(8)
                self.eau_ABE_marker.setIconType(QgsVertexMarker.ICON_BOX)
                self.eau_ABE_marker.setPenWidth(2)
                self.eau_ABE_marker.updatePosition()

    def update_largage_eau_HBE(self, model):
        list_points = model.largage_eau_HBE[len(model.largage_eau_HBE)-1]
        if len(list_points) > 1:
            dernier_point2 = QgsPointXY(list_points[len(list_points) - 2].x(), list_points[len(list_points) - 2].y())
            dernier_point = QgsPointXY(list_points[len(list_points) - 1].x(), list_points[len(list_points) - 1].y())
            #print(dernier_point)
            print(dernier_point2)
            p1 = QgsPointXY(dernier_point2.x(), dernier_point2.y())
            p2 = QgsPointXY(dernier_point.x(), dernier_point.y())
            largeur = p2.x() - p1.x()
            hauteur = p2.y() - p1.y()

            dernierSegment = []
            dernierSegment.append(p1)
            dernierSegment.append(p2)

            rubber = QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry)
            polygon = QgsGeometry.fromPolylineXY(dernierSegment)

            longueur = math.sqrt(largeur ** 2 + hauteur ** 2)
            nb_point = int(longueur / 15)

            rubber.setToGeometry(polygon, None)
            rubber.setColor(QColor(0, 110, 255, 255))
            rubber.setLineStyle(Qt.DotLine)
            rubber.setWidth(3)

            self.ligne_jalonnement_marker = QgsVertexMarker(self.canvas_)
            self.ligne_jalonnement_marker.setCenter(p1)
            self.ligne_jalonnement_marker.setColor(QColor(0, 110, 255))
            self.ligne_jalonnement_marker.setFillColor(QColor(255, 255, 255))
            self.ligne_jalonnement_marker.setIconSize(10)
            self.ligne_jalonnement_marker.setIconType(QgsVertexMarker.ICON_CIRCLE)
            self.ligne_jalonnement_marker.setPenWidth(2)
            self.ligne_jalonnement_marker.updatePosition()


            for i in range(0, nb_point):
                dx = largeur / nb_point
                dy = hauteur / nb_point
                p = QgsPointXY(dernier_point.x() - dx * i, dernier_point.y() - dy * i)
                self.ligne_jalonnement_marker = QgsVertexMarker(self.canvas_)
                self.ligne_jalonnement_marker. setCenter(p)
                self.ligne_jalonnement_marker.setColor(QColor(0, 110, 255))
                self.ligne_jalonnement_marker.setFillColor(QColor(255, 255, 255))
                self.ligne_jalonnement_marker.setIconSize(10)
                self.ligne_jalonnement_marker.setIconType(QgsVertexMarker.ICON_CIRCLE)
                self.ligne_jalonnement_marker.setPenWidth(2)
                self.ligne_jalonnement_marker.updatePosition()

    def update_largage_retartant_ABE(self, model):
        list_points = model.largage_retardant_ABE[len(model.largage_retardant_ABE) - 1]
        if len(list_points) > 1:

            dernier_point2 = QgsPointXY(list_points[len(list_points) - 2].x(), list_points[len(list_points) - 2].y())
            dernier_point = QgsPointXY(list_points[len(list_points) - 1].x(), list_points[len(list_points) - 1].y())
            # print(dernier_point)
            print(dernier_point2)
            p1 = QgsPointXY(dernier_point2.x(), dernier_point2.y())
            p2 = QgsPointXY(dernier_point.x(), dernier_point.y())
            largeur = p2.x() - p1.x()
            hauteur = p2.y() - p1.y()

            dernierSegment = []
            dernierSegment.append(p1)
            dernierSegment.append(p2)

            rubber = QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry)
            polygon = QgsGeometry.fromPolylineXY(dernierSegment)

            longueur = math.sqrt(largeur ** 2 + hauteur ** 2)
            nb_point = int(longueur / 15)

            rubber.setToGeometry(polygon, None)
            rubber.setColor(QColor(255, 0, 0, 255))
            rubber.setLineStyle(Qt.DotLine)
            rubber.setWidth(3)

            self.retartant_ABE_marker2 = QgsVertexMarker(self.canvas_)
            self.retartant_ABE_marker2.setCenter(p1)
            self.retartant_ABE_marker2.setColor(QColor(255, 255, 255))
            self.retartant_ABE_marker2.setIconSize(4)
            self.retartant_ABE_marker2.setIconType(QgsVertexMarker.ICON_BOX)
            self.retartant_ABE_marker2.setPenWidth(4)

            self.retartant_ABE_marker = QgsVertexMarker(self.canvas_)
            self.retartant_ABE_marker.setCenter(p1)
            self.retartant_ABE_marker.setColor(QColor(255, 0, 0))
            self.retartant_ABE_marker.setFillColor(QColor(255, 255, 255))
            self.retartant_ABE_marker.setIconSize(8)
            self.retartant_ABE_marker.setIconType(QgsVertexMarker.ICON_BOX)
            self.retartant_ABE_marker.setPenWidth(2)

            for i in range(0, nb_point):
                dx = largeur / nb_point
                dy = hauteur / nb_point
                p = QgsPointXY(dernier_point.x() - dx * i, dernier_point.y() - dy * i)

                self.retartant_ABE_marker2 = QgsVertexMarker(self.canvas_)
                self.retartant_ABE_marker2.setCenter(p)
                self.retartant_ABE_marker2.setColor(QColor(255, 255, 255))
                self.retartant_ABE_marker2.setIconSize(4)
                self.retartant_ABE_marker2.setIconType(QgsVertexMarker.ICON_BOX)
                self.retartant_ABE_marker2.setPenWidth(4)

                self.retartant_ABE_marker = QgsVertexMarker(self.canvas_)
                self.retartant_ABE_marker. setCenter(p)
                self.retartant_ABE_marker.setColor(QColor(255, 0, 0))
                self.retartant_ABE_marker.setFillColor(QColor(255, 255, 255))
                self.retartant_ABE_marker.setIconSize(8)
                self.retartant_ABE_marker.setIconType(QgsVertexMarker.ICON_BOX)
                self.retartant_ABE_marker.setPenWidth(2)

    def update_largage_retartant_HBE(self, model):
        list_points = model.largage_retardant_HBE[len(model.largage_retardant_HBE) - 1]
        if len(list_points) > 1:

            dernier_point2 = QgsPointXY(list_points[len(list_points) - 2].x(), list_points[len(list_points) - 2].y())
            dernier_point = QgsPointXY(list_points[len(list_points) - 1].x(), list_points[len(list_points) - 1].y())
            # print(dernier_point)
            print(dernier_point2)
            p1 = QgsPointXY(dernier_point2.x(), dernier_point2.y())
            p2 = QgsPointXY(dernier_point.x(), dernier_point.y())
            largeur = p2.x() - p1.x()
            hauteur = p2.y() - p1.y()

            dernierSegment = []
            dernierSegment.append(p1)
            dernierSegment.append(p2)

            rubber = QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry)
            polygon = QgsGeometry.fromPolylineXY(dernierSegment)

            longueur = math.sqrt(largeur ** 2 + hauteur ** 2)
            nb_point = int(longueur / 15)

            rubber.setToGeometry(polygon, None)
            rubber.setColor(QColor(255, 0, 0, 255))
            rubber.setLineStyle(Qt.DotLine)
            rubber.setWidth(3)

            self.eua_retartant_maker = QgsVertexMarker(self.canvas_)
            self.eua_retartant_maker.setCenter(p1)
            self.eua_retartant_maker.setColor(QColor(255, 0, 0))
            self.eua_retartant_maker.setFillColor(QColor(255, 255, 255))
            self.eua_retartant_maker.setIconSize(10)
            self.eua_retartant_maker.setIconType(QgsVertexMarker.ICON_CIRCLE)
            self.eua_retartant_maker.setPenWidth(2)

            for i in range(0, nb_point):
                dx = largeur / nb_point
                dy = hauteur / nb_point
                p = QgsPointXY(dernier_point.x() - dx * i, dernier_point.y() - dy * i)
                self.eua_retartant_maker = QgsVertexMarker(self.canvas_)
                self.eua_retartant_maker.setCenter(p)
                self.eua_retartant_maker.setColor(QColor(255, 0, 0))
                self.eua_retartant_maker.setFillColor(QColor(255, 255, 255))
                self.eua_retartant_maker.setIconSize(10)
                self.eua_retartant_maker.setIconType(QgsVertexMarker.ICON_CIRCLE)
                self.eua_retartant_maker.setPenWidth(2)

    def update_jalonnement(self, model):
        list_points = model.jalonnement_[len(model.jalonnement_) - 1]
        if len(list_points) > 1:

            print(QgsPointXY(list_points[len(list_points) - 1].x(), list_points[len(list_points) - 1].y()))
            rubber = QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry)
            polygon = QgsGeometry.fromPolylineXY(list_points)
            rubber.setToGeometry(polygon, None)
            rubber.setColor(QColor(0, 0, 0, 255))
            rubber.setLineStyle(Qt.DashLine)
            rubber.setWidth(3)

    def update_appui(self, model):
        list_points = model.appui_[len(model.appui_) - 1]

        if len(list_points) > 1:

            rubber1 = QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry)
            rubber2 = QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry)
            polygon = QgsGeometry.fromPolylineXY(list_points)
            rubber1.setToGeometry(polygon, None)
            rubber1.setColor(QColor(0, 0, 0, 255))
            rubber1.setLineStyle(Qt.SolidLine)
            rubber1.setWidth(8)

            rubber2.setToGeometry(polygon, None)
            rubber2.setColor(QColor(255, 255, 255, 255))
            rubber2.setLineStyle(Qt.SolidLine)
            rubber2.setWidth(4)

    def update_obstacle(self, model):
        list_points = model.obstacle_[len(model.obstacle_) - 1]

        if len(list_points) > 1:
            dernier_point2 = QgsPointXY(list_points[len(list_points) - 2].x(), list_points[len(list_points) - 2].y())
            dernier_point = QgsPointXY(list_points[len(list_points) - 1].x(), list_points[len(list_points) - 1].y())
            # print(dernier_point)
            print(dernier_point2)
            p1 = QgsPointXY(dernier_point2.x(), dernier_point2.y())
            p2 = QgsPointXY(dernier_point.x(), dernier_point.y())
            largeur = p2.x() - p1.x()
            hauteur = p2.y() - p1.y()

            dernierSegment = []
            dernierSegment.append(p1)
            dernierSegment.append(p2)

            rubber = QgsRubberBand(self.canvas_, QgsWkbTypes.PolygonGeometry)
            polygon = QgsGeometry.fromPolylineXY(dernierSegment)

            longueur = math.sqrt(largeur ** 2 + hauteur ** 2)
            nb_point = int(longueur / 15)

            rubber.setToGeometry(polygon, None)
            rubber.setColor(QColor(170, 60, 170, 255))
            rubber.setLineStyle(Qt.DotLine)
            rubber.setWidth(3)
            for i in range(0, nb_point):
                dx = largeur / nb_point
                dy = hauteur / nb_point
                p = QgsPointXY(dernier_point.x() - dx * i, dernier_point.y() - dy * i)
                self.obstacle_marker = QgsVertexMarker(self.canvas_)
                self.obstacle_marker.setCenter(p)
                self.obstacle_marker.setColor(QColor(170, 60, 170))
                self.obstacle_marker.setFillColor(QColor(255, 255, 255))
                self.obstacle_marker.setIconSize(10)
                self.obstacle_marker.setIconType(QgsVertexMarker.ICON_X)
                self.obstacle_marker.setPenWidth(2)
                self.obstacle_marker.updatePosition()

    ###---Procedures de chargement du fond de carte---###

    def change(self, departement):
        datas = "{}\\{}".format(os.path.expanduser("~\\Documents"), departement)
        ext = ".jp2"
        self.thread_ = MapLoader(self, datas, ext)
        self.thread_.end.connect(self.finish)
        self.thread_.progress.connect(self.progress)
        self.thread_.start()
        
    def finish(self, layers):
        self.layers = layers
        self.canvas_.setExtent(layers[1].extent())
        self.canvas_.setLayers(layers)
        self.canvas_.refresh()
        self.progress(0)
        
    def progress(self, percent):
        self.progressbar_.setValue(percent)


    #Classe responsable du chargemnt de la carte
class MapLoader(QThread):
    end = pyqtSignal(list)
    progress = pyqtSignal(int)

    def __init__(self, santoline_view, datas, ext):
        QThread.__init__(self)
        self.datas_ = datas
        self.ext_ = ext
        
    def __del__(self):
        self.wait()
        
    def run(self):
        list = useful.allFiles(self.datas_, self.ext_)
        if (len(list) == 0 ):
            return
            
        layers = []
        total_len = len(list)
        def runner():
            try:
                while (len(list) > 0):
                    i = list.pop()
                    layer = QgsRasterLayer(i, i)
                    if (not layer.isValid()):
                        raise IOError("Fail to open the layer {}".format(i))
                    layers.append(layer)
                    self.progress.emit(100 - int((len(list) / total_len) * 100.))
            except IndexError: # catch if we pop an empty list.
                pass
                
        threads = [threading.Thread(target=runner) for i in range(useful.thread_quantity() - 1)]
        for thread in threads: thread.start()
        for thread in threads: thread.join()
        self.end.emit(layers)
