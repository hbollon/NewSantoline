from qgis.PyQt.QtWidgets import *

from . import input_popup_view
from ..controller import *

class Legend_Window(input_popup_view.InputPopup):
    def __init__(self):
        
        self.ok_ = None
        
        super().__init__(legend_controller.Legend_Controller(self))

    def initUI(self):
        self.setWindowTitle("Légende")
        body = QVBoxLayout(self)

        boutons = QWidget(self)
        boutons_layout = QHBoxLayout(boutons)
        self.ok_ = QPushButton("Ok", boutons)

        boutons_layout.addWidget(self.ok_)
        boutons.setLayout(boutons_layout)

        body.addWidget(boutons)
        
        self.setLayout(body)
        
        self.ok_.clicked.connect(self.controller_.close)
        