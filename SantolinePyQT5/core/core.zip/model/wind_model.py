from . import model, canvas_model
class WindModel(model.AModel):
    def __init__(self, controller):
        super().__init__(controller)
        self.width_ = 0
        self.height_ = 0
        self.direction_ = 0
        self.speed_ = 0.
        self.process_ = 1

    def width(self, width):
        self.width_ = width
        self.notifyObservers()
        
    def height(self, height):
        self.height_ = height
        self.notifyObservers()
        
    def direction(self, direction):
        self.direction_ = direction
        self.notifyObservers()
        
    def speed(self, speed):
        self.speed_ = speed
        self.notifyObservers()

    def process(self, process):
        self.process_ = process
        self.notifyObservers()
        
    def jsonify(self):
        origin = (self.direction_ + 180.)%360.
        if (origin > 270):
            origin -= 360
        direction = 270 - origin
        print(direction)
        json = {
            #"type": "parametreepilobe",
            #"epilobe": {
                "axeorigine": "est",
                "direction": round(self.direction_, 1),
                "force": round(self.speed_, 1),
                "nbProcess": 2,
                "dimension": [round(self.width_, 1), round(self.height_, 1)],
                "origine": canvas_model.CanvasModel(self.controler_).centroids()
            #}
        }
        print("json vent :")
        print(json)
        return json
