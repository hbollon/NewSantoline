from . import model
from qgis.PyQt.QtCore import QTime
class AlgorithmModel(model.AModel):
    def __init__(self, controller):
        super().__init__(controller)
        self.algorithm_ = ""
        self.duree_ = QTime(0,0)
        self.waterReserve_ = 0
        self.temperature_ = 0
        self.process_ = 0
        self.dimension_ = 25
        self.nbDivisionCellule_ = 25
        
    def algorithm(self, algorithm):
        self.algorithm_ = algorithm
        self.notifyObservers()
        
    def duree(self, duree):
        self.duree_ = duree
        self.notifyObservers()
        
    def waterReserve(self, waterReserve):
        self.waterReserve_ = waterReserve
        self.notifyObservers()
        
    def temperature(self, temperature):
        self.temperature_ = temperature
        self.notifyObservers()

    def process(self, process):
        self.process_ = process
        self.notifyObservers()
    
    def dimension(self, dimension):
        self.dimension_ = dimension
        self.notifyObservers()

    def nbDivisionCellule(self, nbDivisionCellule):
        self.nbDivisionCellule_ = nbDivisionCellule
        self.notifyObservers()
        
    def jsonify(self):
        duree = self.duree_.hour() + self.duree_.minute() / 60.
        return {
            "type" : "parametrealgorithme",
            "json" : {
                "paramSim" : {
                    "temperature" : round(self.temperature_,1),
                    "waterReserve" : round(self.waterReserve_,1),
                    "duration" : round(duree,1),
                    "nbProcess" : round(self.process_,1),
                    "algorithm" : self.algorithm_,
                    "dimension" : round(25.0,1)
                }
            }
        }
    